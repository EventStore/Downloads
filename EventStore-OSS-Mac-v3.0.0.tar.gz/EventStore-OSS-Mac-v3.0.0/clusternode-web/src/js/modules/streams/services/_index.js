define([
    './StreamsService'
], function () {});