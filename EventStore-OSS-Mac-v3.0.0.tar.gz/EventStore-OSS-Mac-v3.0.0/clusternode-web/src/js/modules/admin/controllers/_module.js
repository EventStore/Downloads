define(['angular'], function (ng) {
    'use strict';
    return ng.module('es-ui.admin.controllers', [
    	'es-ui.admin.services'
	]);
});