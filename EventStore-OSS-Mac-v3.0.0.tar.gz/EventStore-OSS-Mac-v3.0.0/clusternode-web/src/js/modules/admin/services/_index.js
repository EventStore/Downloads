define([
    './AdminService'
], function () {});