define([
    './ProjectionsItemDebugCtrl',
	'./ProjectionsItemDeleteCtrl',
	'./ProjectionsItemDetailsCtrl',
	'./ProjectionsItemEditCtrl',
	'./ProjectionsListCtrl',
	'./ProjectionsNewCtrl',
	'./ProjectionsStandardCtrl',
	'./QueryCtrl'
], function () {});