define([
    './SignInCtrl',
    './SignOutCtrl'
], function () {});