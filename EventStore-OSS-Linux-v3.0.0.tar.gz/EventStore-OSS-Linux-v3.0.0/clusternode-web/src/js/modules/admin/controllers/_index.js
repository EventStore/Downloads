define([
    './AdminCtrl'
], function () {});