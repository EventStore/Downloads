define([
    './DashboardMapper',
    './DashboardService'
], function () {});