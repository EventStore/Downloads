define([
    './DashboardListCtrl',
	'./DashboardSnapshotCtrl'
], function () {});