define([
    './UsersItemDeleteCtrl',
	'./UsersItemDetailsCtrl',
	'./UsersItemDisableCtrl',
	'./UsersItemEditCtrl',
	'./UsersItemEnableCtrl',
	'./UsersItemResetCtrl',
	'./UsersListCtrl',
	'./UsersNewCtrl'
], function () {});