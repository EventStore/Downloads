define(['angular'], function (ng) {
    'use strict';
    return ng.module('es-ui.projections.controllers', [
    	'es-ui.projections.services'
	]);
});