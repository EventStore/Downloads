define([
    './EsProjDebugFrame'
], function () {});