define(['es-ui'], function (app) {

	'use strict';
	return app.constant('constants', {
		projectionStatus: {
			running: 'Running',
			stopped: 'Stopped'
		}
	});
});