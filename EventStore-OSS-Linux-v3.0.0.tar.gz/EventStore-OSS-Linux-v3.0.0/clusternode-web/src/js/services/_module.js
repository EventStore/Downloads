define(['angular', 'ngCookies'], function (ng) {
    'use strict';
    return ng.module('es-ui.services', ['ngCookies']);
});