define([
    './templates'
], function () {});