##!/usr/bin/env bash

LD_LIBRARY_PATH=.:$LD_LIBRARY_PATH ./clusternode $@
