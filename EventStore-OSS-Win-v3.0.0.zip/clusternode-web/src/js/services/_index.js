define([
	'./Uri',
    './Base64',
    './Poller',
    './UrlBuilder',
    './SprintfService',
    './AuthService',
    './MessageService'
], function () {});