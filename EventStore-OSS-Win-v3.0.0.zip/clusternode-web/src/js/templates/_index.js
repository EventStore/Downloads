define([
    './templates'
], function () {});