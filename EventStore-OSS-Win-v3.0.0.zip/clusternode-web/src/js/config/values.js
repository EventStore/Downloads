define(['es-ui'], function (app) {

	'use strict';

	return app.value('baseUrl', {});

});