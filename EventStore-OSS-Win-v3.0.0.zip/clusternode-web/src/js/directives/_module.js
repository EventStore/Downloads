define(['angular'], function (ng) {
    'use strict';
    return ng.module('es-ui.directives', []);
});