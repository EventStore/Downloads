define([
    './StreamsService'
], function () {});