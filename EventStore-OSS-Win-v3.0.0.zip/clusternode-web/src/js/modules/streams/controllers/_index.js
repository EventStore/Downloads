define([
    './StreamsItemEventCtrl',
	'./StreamsItemEventsCtrl',
	'./StreamsItemAclCtrl',
	'./StreamsListCtrl'
], function () {});