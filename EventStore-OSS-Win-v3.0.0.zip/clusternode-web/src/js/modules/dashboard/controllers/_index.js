define([
    './DashboardListCtrl',
	'./DashboardSnapshotCtrl'
], function () {});