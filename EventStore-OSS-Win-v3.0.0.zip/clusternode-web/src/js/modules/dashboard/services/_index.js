define([
    './DashboardMapper',
    './DashboardService'
], function () {});