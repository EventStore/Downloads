define([
    './AdminCtrl'
], function () {});