define([
    './AdminService'
], function () {});