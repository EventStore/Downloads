define([
    './SignInCtrl',
    './SignOutCtrl'
], function () {});