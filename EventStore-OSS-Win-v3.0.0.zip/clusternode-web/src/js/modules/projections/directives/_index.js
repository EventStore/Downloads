define([
    './EsProjDebugFrame'
], function () {});