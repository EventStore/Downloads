define([
    './ProjectionsService',
    './ProjectionsMapper',
    './ProjectionsMonitor',
    './QueryService',
    './AtomEventsReader'
], function () {});