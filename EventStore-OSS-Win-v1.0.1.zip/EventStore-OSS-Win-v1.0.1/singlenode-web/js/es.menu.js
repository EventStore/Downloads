es.util.loadMenu([
    { "name": "Home", "link": "/web/home.htm", "class": "" },
    { "name": "Streams", "link": "/web/streams.htm", "class": "" },
    { "name": "Projections", "link": "/web/projections.htm", "class": "" },
    { "name": "Query", "link": "/web/query.htm", "class": "" },
    { "name": "Charts", "link": "/web/charts.htm", "class": "" },
    { "name": "Health Charts", "link": "/web/health-charts.htm", "class": "" },
    { "name": "Queues", "link": "/web/queues.htm", "class": "" }
]);